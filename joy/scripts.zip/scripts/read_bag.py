from bagpy import bagreader
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


class ExpResult:

    def __init__(self, f_name):
        temp = f_name.split('_')
        self.label = temp[2] + '_' + temp[3] + temp[4]
        f_dir = '/home/cflai/catkin_ws_py/bag_file/VS_exp/atten_10_08/' + f_name
        b = bagreader(f_dir)
        motors_states_sync = b.message_by_topic('/motors_states_sync')
        target_centroid_sync = b.message_by_topic('/target_centroid_sync')
        vel_array_sync = b.message_by_topic('/vel_array_sync')
        # time_stamp = b.message_by_topic('/motors_states_sync')
        df_motors_states_sync = pd.read_csv(motors_states_sync)
        df_target_centroid_sync = pd.read_csv(target_centroid_sync)
        df_vel_array_sync = pd.read_csv(vel_array_sync)
        # df_time_stamp = pd.read_csv(time_stamp)

        time_stamp = df_motors_states_sync["Time"].tolist()
        time_stamp = np.array(time_stamp)
        encoders = df_motors_states_sync["data_0"].tolist()
        encoders = np.array(encoders)
        target_x = df_target_centroid_sync["data_0"].tolist()
        target_x = np.array(target_x)
        target_y = df_target_centroid_sync["data_1"].tolist()
        target_y = np.array(target_y)
        vel_array_sync = df_vel_array_sync["data_2"].tolist()
        vel_array_sync = np.array(vel_array_sync)

        self.time_stamp = time_stamp
        self.encoders = encoders
        self.target_x = target_x
        self.target_y = target_y
        self.vel_array_sync = vel_array_sync

        self.len = len(time_stamp)

    def plot(self, sync_const=0):
        fig, ax = plt.subplots()
        data_len = len(self.encoders)
        ax.scatter(self.encoders[0:data_len - sync_const], self.target_y[sync_const:])
        ax.set_title('VS target vs Motor revolution' + '(' + self.label + ')')
        # plt.scatter(self.encoders, self.target_x, label=label)


file_dir = [
    # '10-08-2022_attenuated_a400_T_8_fc_0_15_tc_02_r_2.bag',
    # '10-08-2022_attenuated_a500_T_10_fc_0_15_tc_02_r_2.bag',
    '10-08-2022_attenuated_a600_T_12_fc_0_15_tc_02_r_2.bag',
    # '10-08-2022_attenuated_a500_T_12_fc_0_15_tc_02_r_1.bag',
    # '10-08-2022_attenuated_a600_T_16_fc_0_15_tc_02_r_1.bag',
    # '10-08-2022_attenuated_a600_T_16_fc_0_15_tc_02_r_2.bag'
            ]

fig, ax = plt.subplots()

for exp in file_dir:
    exp_result = ExpResult(exp)
    ax.scatter(exp_result.encoders, exp_result.target_x, label=exp_result.label)

plt.legend()
plt.show()

###########
#
# file_dir_2 = [
#     # '10-08-2022_attenuated_a400_T_8_fc_0_15_tc_02_r_2.bag',
#     '10-08-2022_attenuated_a500_T_10_fc_0_15_tc_02_r_2.bag',
#     # '10-08-2022_attenuated_a600_T_12_fc_0_15_tc_02_r_2.bag',
#     '10-08-2022_attenuated_a500_T_12_fc_0_15_tc_02_r_1.bag',
#     # '10-08-2022_attenuated_a500_T_12_fc_0_15_tc_02_r_2.bag',
#     # '10-08-2022_attenuated_a600_T_16_fc_0_15_tc_02_r_1.bag',
#     # '10-08-2022_attenuated_a600_T_16_fc_0_15_tc_02_r_2.bag'
#             ]
#
# fig2, ax2 = plt.subplots()
#
# for exp in file_dir_2:
#     exp_result = ExpResult(exp)
#     ax2.scatter(exp_result.encoders, exp_result.target_x, label=exp_result.label)
#
# plt.legend()
# plt.show()
