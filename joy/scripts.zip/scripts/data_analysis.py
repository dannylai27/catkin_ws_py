from bagpy import bagreader
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

b = bagreader('/home/cflai/catkin_ws_py/bag_file/VS_exp/atten_10_08/10-08-2022_attenuated_a800_T_16_fc_0_15_tc_02_r_2'
              '.bag')

# 10-08-2022_attenuated_a400_T_8_fc_0_15_tc_02_r_2.bag
# 10-08-2022_attenuated_a500_T_10_fc_0_15_tc_02_r_2.bag
# 10-08-2022_attenuated_a600_T_12_fc_0_15_tc_02_r_2.bag

motors_states_sync = b.message_by_topic('/motors_states_sync')
df_motors_states_sync = pd.read_csv(motors_states_sync)
target_centroid_sync = b.message_by_topic('/target_centroid_sync')
df_target_centroid_sync = pd.read_csv(target_centroid_sync)
vel_array_sync = b.message_by_topic('/vel_array_sync')
df_vel_array_sync = pd.read_csv(vel_array_sync)

motors_states = b.message_by_topic('/motors_states')
df_motors_states = pd.read_csv(motors_states)
target_centroid = b.message_by_topic('/target_centroid')
df_target_centroid = pd.read_csv(target_centroid)

time_stamp = df_motors_states_sync["Time"].tolist()
time_stamp = np.array(time_stamp)
encoders = df_motors_states_sync["data_0"].tolist()
encoders = np.array(encoders)
target_x = df_target_centroid_sync["data_0"].tolist()
target_x = np.array(target_x)
target_y = df_target_centroid_sync["data_1"].tolist()
target_y = np.array(target_y)

# encoders = df_motors_states["data_0"].tolist()
# encoders = np.array(encoders)
# target_x = df_target_centroid["data_0"].tolist()
# target_x = np.array(target_x)
# time_stamp_M = df_motors_states["Time"].tolist()
# time_stamp_M = np.array(time_stamp_M)
# time_stamp_T = df_target_centroid["Time"].tolist()
# time_stamp_T = np.array(time_stamp_T)


plt.figure(dpi=180)
# plt.scatter(time_stamp_M[100:130], encoders[100:130], marker='x', label='motor')
# plt.scatter(time_stamp_T[70:110], target_x[70:110], marker='x', label='CV')

# plt.scatter(encoders, target_x, label='y')
plt.scatter(encoders[0:-2], target_x[2:], label='f_1')
plt.legend()
# plt.scatter(encoders, target_y, label='y')
plt.show()
